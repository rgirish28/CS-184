
#pragma once

// shortcut methods
// TODO: Clean this up. ;)
char* trim(char* line);
bool isEmpty(char* line);
void con(char* line);
